# W1 D2 - JavaScript Fundamentals [Sunday] 

*Agenda*

- Recap
- Conditional Statements
- Looping
- String
- Arrays


In this module, we will take a look at the following

# Strings

 - Defining a string
 - String object/class
 - Methods in String
    
# Arrays

 - Defining an array
 - Array object/class
 - Methods & operations on an array
