var browserName = 'chrome';
browserName = 'safari';
console.log(browserName);
var companyName = 'Testleaf';
companyName = 'Qeagle';
console.log(typeof companyName);
var testReport;
testReport = 'Pass';
console.log(typeof testReport);
