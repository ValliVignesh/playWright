let browserName = 'chrome';
browserName = 'safari';
console.log(browserName);

let companyName = 'Testleaf';
companyName = 'Qeagle';
console.log(typeof companyName );

let testReport: any = 'Pass';
testReport= 'Pass';
testReport = 123;
console.log(typeof testReport);

