let companyName = 'Testleaf';
companyName = 123;
companyName = true;
console.log(typeof companyName);