var response = "Success";
//let responseString: string = <string>response;
var responseLength = response.length;
console.log(responseLength);
var statusCode = 201;
var statusNum = statusCode;
console.log(statusNum);
