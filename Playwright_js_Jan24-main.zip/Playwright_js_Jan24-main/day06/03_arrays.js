var list = [1, 2, 3, 4, 5];
console.log(list);
//removes the elements in the array and you can insert new elements to the array
list.splice(2, 2, 6);
console.log(list);
var list1 = [1, 2, 3, 4, 5];
console.log(list1);
//removes the elements in the array and you can insert new elements to the array
list1.splice(2, 2, "chrome", "safari");
console.log(list1);
